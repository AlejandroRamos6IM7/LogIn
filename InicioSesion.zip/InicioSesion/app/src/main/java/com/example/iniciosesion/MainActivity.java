package com.example.iniciosesion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Usuario;
    private EditText Pass;
    private TextView Texto;
    private Button BotonIniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Usuario = (EditText)findViewById(R.id.TextUsuario);
        Pass = (EditText)findViewById(R.id.TextPass);
        Texto = (TextView)findViewById(R.id.TextBienvenido);
        BotonIniciar = (Button)findViewById(R.id.BotonIniciar);

        BotonIniciar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
               Iniciar(Usuario.getText().toString(), Pass.getText().toString());
            }

        });
    }


    private void Iniciar(String Usuario, String Pass){
        if(Usuario.equals("Alex") && Pass.equals("Bros")){
            Intent Entrar = new Intent(this, ActivityInicio.class);
            Bundle guardadito = new Bundle();
            guardadito.putString("Usuario", Usuario);
            Entrar.putExtras(guardadito);
            startActivity(Entrar);
        }else {
            Toast error = Toast.makeText(getApplicationContext(), "Usuario o Contraseña Incorrectos", Toast.LENGTH_SHORT);
            error.show();

        }
    }
}
