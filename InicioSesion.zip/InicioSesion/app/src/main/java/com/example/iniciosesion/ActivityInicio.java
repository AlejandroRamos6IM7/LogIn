package com.example.iniciosesion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ActivityInicio extends AppCompatActivity {

    private TextView Bienvenido;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        Bundle traer = new Bundle();
        traer = this.getIntent().getExtras();
        Bienvenido = (TextView)findViewById(R.id.TextBienvenido) ;
        Bienvenido.setText("Bienvenido " + traer.getString("Usuario"));
    }
}
